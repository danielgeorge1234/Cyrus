﻿using Domain.Dtos.ClientDto;
using Domain.ParameterFeatures;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Service.Contracts.Dtos;
using Service.Contracts.Dtos.LegalAccountantDto;
using Service.Contracts.Managers;
using Service.Contracts.Pagination;
using Services;
using System.Drawing.Printing;

namespace CyrusCRM.Controllers
{
    public class ClientController : Controller
    {
        private readonly IServiceManager _serviceManager;

        public ClientController(IServiceManager serviceManager)
        {
            _serviceManager=serviceManager;
        }


        // GET: Client
        [HttpGet]
        public async Task<IActionResult> Index([FromQuery]ClientFilter filter)
        {
            var paginatedClients = await _serviceManager.ClientManager.GetClientsPaginatedAsync(filter);
           
            return View(paginatedClients);


        }

        // GET: Client/Details/5
        [HttpGet]
        public async Task<ActionResult<ClientDto>> Details(int id)
        {
            var client = await _serviceManager.ClientManager.GetClientByIdAsync(id);
            if (client == null)
            {
                return NotFound();
            }
            return View(client);
        }

        // GET: Client/Create
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // POST: Client/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(ClientDto clientDto)
        {
            if (ModelState.IsValid)
            {
                await _serviceManager.ClientManager.AddClientAsync(clientDto);
                return RedirectToAction(nameof(Index));

            }
            return View(clientDto);
        }

        // GET: Client/Edit/5
        [HttpGet]
        public async Task<ActionResult> Edit(int id)
        {
            var client = await _serviceManager.ClientManager.GetClientByIdAsync(id);
            if (client == null)
            {
                return NotFound();
            }
            return View(client);
        }

        // POST: Client/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, ClientDto clientDto)
        {
      

            if (ModelState.IsValid)
            {
                await _serviceManager.ClientManager.UpdateClientAsync(clientDto);
                return RedirectToAction(nameof(Index));
            }
            return View(clientDto);
        }

        // GET: Client/Delete/5
        [HttpGet]
        public async Task<ActionResult> Delete(int id)
        {
            var client = await _serviceManager.ClientManager.GetClientByIdAsync(id);
            if (client == null)
            {
                return NotFound();
            }
            return View(client);
        }

        // POST: Client/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var client = await _serviceManager.ClientManager.GetClientByIdAsync(id);
            if (client == null)
            {
                return NotFound();
            }

            await _serviceManager.ClientManager.DeleteClientAsync(id);
            return RedirectToAction(nameof(Index));

        }

        [HttpGet]
        public async Task<IActionResult> GetLegalAccountantByClient(int Id)
        {


            var client = await _serviceManager.ClientManager.GetClientByIdAsync(Id);

            if (client == null)
            {
                return NotFound();
            }

            var legalAccountantDto = new ClientLegalAccountantDto
            {
                LegalAccountantId = client.Id,
                Name = client.Name,  // Ensure these properties exist
                Phone1 = client.Phone1  // Ensure these properties exist
            };

            return Ok(legalAccountantDto);

        }



    }
}

    

