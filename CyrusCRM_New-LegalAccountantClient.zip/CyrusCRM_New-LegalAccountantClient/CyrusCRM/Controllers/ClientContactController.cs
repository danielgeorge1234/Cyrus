﻿using Microsoft.AspNetCore.Mvc;
using Service.Contracts.Dtos.ClientContactDto;
using Service.Contracts.Managers;
using Services;

namespace CyrusCRM.Controllers
{
    public class ClientContactController : Controller
    {
        private readonly IServiceManager _serviceManager;

        public ClientContactController(IServiceManager serviceManager) 
        {
           _serviceManager = serviceManager;
        }


        public async Task<IActionResult> Index(string searchString)
        {

            var clientContacts = await _serviceManager.ClientContactManager.GetAllClientContactsAsync();
      
            return View(clientContacts);
        }

        // GET: ClientContact/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var clientContact = await _serviceManager.ClientContactManager.GetClientContactByIdAsync(id);
            if (clientContact == null)
            {
                return NotFound();
            }
            return View(clientContact);
        }

        // GET: ClientContact/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: ClientContact/Create
        [HttpPost("Create")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ClientContactDto clientContactDto)
        {
            if (ModelState.IsValid)
            {
                await _serviceManager.ClientContactManager.AddClientContactAsync(clientContactDto);
                return RedirectToAction(nameof(Index));
            }
            return View(clientContactDto);
        }

        // GET: ClientContact/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            var clientContact = await _serviceManager.ClientContactManager.GetClientContactByIdAsync(id);
            if (clientContact == null)
            {
                return NotFound();
            }
            return View(clientContact);
        }

        // POST: ClientContact/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, ClientContactDto clientContactDto)
        {
            if (id != clientContactDto.Id)
            {
                return BadRequest();
            }

            if (ModelState.IsValid)
            {
                await _serviceManager.ClientContactManager.UpdateClientContactAsync(clientContactDto);
                return RedirectToAction(nameof(Index));
            }
            return View(clientContactDto);
        }

        // GET: ClientContact/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            var clientContact = await _serviceManager.ClientContactManager.GetClientContactByIdAsync(id);
            if (clientContact == null)
            {
                return NotFound();
            }
            return View(clientContact);
        }

        // POST: ClientContact/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _serviceManager.ClientContactManager.DeleteClientContactAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}
