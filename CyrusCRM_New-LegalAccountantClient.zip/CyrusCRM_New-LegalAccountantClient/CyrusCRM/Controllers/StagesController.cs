﻿using Microsoft.AspNetCore.Mvc;
using Service.Contracts.Dtos.StagesDto;
using Service.Contracts.Managers;

namespace CyrusCRM.Controllers
{
    public class StagesController : Controller
    {
        private readonly IServiceManager _serviceManager;

        public StagesController(IServiceManager serviceManager)
        {
           _serviceManager = serviceManager;
        }

        // GET: Stages
        [HttpGet]
        public async Task<ActionResult<IEnumerable<StagesDto>>> Index()
        {
            var stages = await _serviceManager.stagesManager.GeAllStagesDtoAsync();
            return View(stages);
        }

        // GET: Stages/Details/5
        [HttpGet]
        public async Task<ActionResult<StagesDto>> Details(int id)
        {
            var stage = await _serviceManager.stagesManager.GetStagesByIdAsync(id);
            if (stage == null)
            {
                return NotFound();
            }
            return View(stage);
        }

        // GET: Stages/Create
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // POST: Stages/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(StagesDto stageDto)
        {
            if (ModelState.IsValid)
            {
                await _serviceManager.stagesManager.AddStagesAsync(stageDto);
                return RedirectToAction(nameof(Index));
            }
            return View(stageDto);
        }

        // GET: Stages/Edit/5
        [HttpGet]
        public async Task<ActionResult> Edit(int id)
        {
            var stage = await _serviceManager.stagesManager.GetStagesByIdAsync(id);
            if (stage == null)
            {
                return NotFound();
            }
            return View(stage);
        }

        // POST: Stages/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, StagesDto stageDto)
        {
            if (id != stageDto.Id)
            {
                return BadRequest();
            }

            if (ModelState.IsValid)
            {
                await _serviceManager.stagesManager.UpdateStagesAsync(stageDto);
                return RedirectToAction(nameof(Index));
            }
            return View(stageDto);
        }

        // GET: Stages/Delete/5
        [HttpGet]
        public async Task<ActionResult> Delete(int id)
        {
            var stage = await _serviceManager.stagesManager.GetStagesByIdAsync(id);
            if (stage == null)
            {
                return NotFound();
            }
            return View(stage);
        }

        // POST: Stages/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var stage = await _serviceManager.stagesManager.GetStagesByIdAsync(id);
            if (stage == null)
            {
                return NotFound();
            }

            await _serviceManager.stagesManager.DeleteStagesAsync(id);
            return RedirectToAction(nameof(Index));
        }



    }
}
