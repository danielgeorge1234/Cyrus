﻿using Microsoft.AspNetCore.Mvc;
using Service.Contracts.Dtos.LeadDto;
using Service.Contracts.Managers;

namespace CyrusCRM.Controllers
{
    public class LeadController : Controller
    {
        private readonly IServiceManager _serviceManager;

        public LeadController(IServiceManager serviceManager)
        {
            _serviceManager = serviceManager;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<LeadDto>>> Index(int id)
        {
            var leads = await _serviceManager.leadManager.GetLeadsAsync();
            return View(leads);
        }

        // GET: Lead/Details/5
        [HttpGet]
        public async Task<ActionResult<LeadDto>> Details(int id)
        {
            var lead = await _serviceManager.leadManager.GetLeadByIdAsync(id);
            if (lead == null)
            {
                return NotFound();
            }
            return View(lead);
        }

        // GET: Lead/Create
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // POST: Lead/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(LeadDto leadDto)
        {
            if (ModelState.IsValid)
            {
                await _serviceManager.leadManager.AddLeadAsync(leadDto);
                return RedirectToAction(nameof(Index));
            }
            return View(leadDto);
        }

        // GET: Lead/Edit/5
        [HttpGet]
        public async Task<ActionResult> Edit(int id)
        {
            var lead = await _serviceManager.leadManager.GetLeadByIdAsync(id);
            if (lead == null)
            {
                return NotFound();
            }
            return View(lead);
        }

        // POST: Lead/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, LeadDto leadDto)
        {
            if (id != leadDto.Id)
            {
                return BadRequest();
            }

            if (ModelState.IsValid)
            {
                await _serviceManager.leadManager.UpdateLeadAsync(leadDto);
                return RedirectToAction(nameof(Index));
            }
            return View(leadDto);
        }

        // GET: Lead/Delete/5
        [HttpGet]
        public async Task<ActionResult> Delete(int id)
        {
            var lead = await _serviceManager.leadManager.GetLeadByIdAsync(id);
            if (lead == null)
            {
                return NotFound();
            }
            return View(lead);
        }

        // POST: Lead/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var lead = await _serviceManager.leadManager.GetLeadByIdAsync(id);
            if (lead == null)
            {
                return NotFound();
            }

            await _serviceManager.leadManager.DeleteLeadAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}
