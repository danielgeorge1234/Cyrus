﻿using Microsoft.AspNetCore.Mvc;
using Service.Contracts.Dtos.LeadHistoryDto;
using Service.Contracts.Managers;
using Services;

namespace CyrusCRM.Controllers
{
    public class LeadHistoryController : Controller
    {
        private readonly IServiceManager _serviceManager;

        public LeadHistoryController(IServiceManager serviceManager)
        {
          _serviceManager = serviceManager;
        }



        [HttpGet]
        public async Task<ActionResult<IEnumerable<LeadHistoryDto>>> Index()
        {
            var leadHistories = await _serviceManager.leadHistoryManager.GetAllLeadHistorysAsync();
            return View(leadHistories);
        }

        // GET: LeadHistory/Details/5
        [HttpGet]
        public async Task<ActionResult<LeadHistoryDto>> Details(int id)
        {
            var leadHistory = await _serviceManager.leadHistoryManager.GetLeadHistoryByIdAsync(id);
            if (leadHistory == null)
            {
                return NotFound();
            }
            return View(leadHistory);
        }

        // GET: LeadHistory/Create
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // POST: LeadHistory/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(LeadHistoryDto leadHistoryDto)
        {
            if (ModelState.IsValid)
            {
                await _serviceManager.leadHistoryManager.AddLeadHistoryAsync(leadHistoryDto);
                return RedirectToAction(nameof(Index));
            }
            return View(leadHistoryDto);
        }

        // GET: LeadHistory/Edit/5
        [HttpGet]
        public async Task<ActionResult> Edit(int id)
        {
            var leadHistory = await _serviceManager.leadHistoryManager.GetLeadHistoryByIdAsync(id);
            if (leadHistory == null)
            {
                return NotFound();
            }
            return View(leadHistory);
        }

        // POST: LeadHistory/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, LeadHistoryDto leadHistoryDto)
        {
            if (id != leadHistoryDto.Id)
            {
                return BadRequest();
            }

            if (ModelState.IsValid)
            {
                await _serviceManager.leadHistoryManager.UpdateLeadHistoryAsync(leadHistoryDto);
                return RedirectToAction(nameof(Index));
            }
            return View(leadHistoryDto);
        }

        // GET: LeadHistory/Delete/5
        [HttpGet]
        public async Task<ActionResult> Delete(int id)
        {
            var leadHistory = await _serviceManager.leadHistoryManager.GetLeadHistoryByIdAsync(id);
            if (leadHistory == null)
            {
                return NotFound();
            }
            return View(leadHistory);
        }

        // POST: LeadHistory/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var leadHistory = await _serviceManager.leadHistoryManager.GetLeadHistoryByIdAsync(id);
            if (leadHistory == null)
            {
                return NotFound();
            }

            await _serviceManager.leadHistoryManager.DeleteLeadHistoryAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}

