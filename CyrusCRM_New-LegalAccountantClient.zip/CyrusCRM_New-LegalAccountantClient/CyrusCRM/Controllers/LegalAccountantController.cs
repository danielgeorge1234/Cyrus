﻿using Microsoft.AspNetCore.Mvc;
using Service.Contracts.Dtos.LegalAccountantDto;
using Service.Contracts.Managers;

namespace CyrusCRM.Controllers
{
    public class LegalAccountantController : Controller
    {
        private readonly IServiceManager _serviceManager;

        public LegalAccountantController(IServiceManager serviceManager)
        {
        _serviceManager = serviceManager;
        }

        // GET: LegalAccountant
        [HttpGet]
        public async Task<ActionResult<IEnumerable<LegalAccountantDto>>> Index()
        {
            var legalAccountants = await _serviceManager.legalAccountantManager.GeAllLegalAccountantAsync();
            return View(legalAccountants);
        }

        // GET: LegalAccountant/Details/5
        [HttpGet]
        public async Task<ActionResult<LegalAccountantDto>> Details(int id)
        {
            var legalAccountant = await _serviceManager.legalAccountantManager.GetLegalAccountByIdAsync(id);
            if (legalAccountant == null)
            {
                return NotFound();
            }
            return View(legalAccountant);
        }

        // GET: LegalAccountant/Create
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // POST: LegalAccountant/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(LegalAccountantDto legalAccountantDto)
        {
            if (ModelState.IsValid)
            {
                await _serviceManager.legalAccountantManager.AddLegalAccountantAsync(legalAccountantDto);
                return RedirectToAction(nameof(Index));
            }
            return View(legalAccountantDto);
        }

        // GET: LegalAccountant/Edit/5
        [HttpGet]
        public async Task<ActionResult> Edit(int id)
        {
            var legalAccountant = await _serviceManager.legalAccountantManager.GetLegalAccountByIdAsync(id);
            if (legalAccountant == null)
            {
                return NotFound();
            }
            return View(legalAccountant);
        }

        // POST: LegalAccountant/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, LegalAccountantDto legalAccountantDto)
        {
            if (id != legalAccountantDto.Id)
            {
                return BadRequest();
            }

            if (ModelState.IsValid)
            {
                await _serviceManager.legalAccountantManager.UpdateLegalAccountantAsync(legalAccountantDto);
                return RedirectToAction(nameof(Index));
            }
            return View(legalAccountantDto);
        }

        // GET: LegalAccountant/Delete/5
        [HttpGet]
        public async Task<ActionResult> Delete(int id)
        {
            var legalAccountant = await _serviceManager.legalAccountantManager.GetLegalAccountByIdAsync(id);
            if (legalAccountant == null)
            {
                return NotFound();
            }
            return View(legalAccountant);
        }

        // POST: LegalAccountant/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var legalAccountant = await _serviceManager.legalAccountantManager.GetLegalAccountByIdAsync(id);
            if (legalAccountant == null)
            {
                return NotFound();
            }

            await _serviceManager.legalAccountantManager.DeleteLegalAccountantAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}

