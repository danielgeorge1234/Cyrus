using CyrusCRM.Extensions;
using Lamar.Microsoft.DependencyInjection;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Authorization;
using Newtonsoft.Json.Serialization;

var builder = WebApplication.CreateBuilder(args);

builder.Host.UseLamar((context,registry) =>
{

    registry.ConfigureSqlContext(builder.Configuration);
    registry.ConfigureAutoMapper();
    registry.ConfigureIdentity();

    registry.AddControllersWithViews().AddNewtonsoftJson(opt => opt.SerializerSettings.ContractResolver = new DefaultContractResolver());

    registry.AddRazorPages().AddRazorRuntimeCompilation();

    //registry.AddControllersWithViews(options =>
    //{
    //    var policy = new AuthorizationPolicyBuilder()
    //           .RequireAuthenticatedUser()
    //           .Build();
    //    options.Filters.Add(new AuthorizeFilter(policy));

    //});

    registry.Configure<CookiePolicyOptions>(options =>
    {
        options.CheckConsentNeeded = context => true;
        options.MinimumSameSitePolicy = SameSiteMode.None;
    });

    registry.AddSession(options => { options.IdleTimeout = TimeSpan.FromHours(1); });

    registry.Scan(s =>
    {
        s.TheCallingAssembly();
        s.WithDefaultConventions();
        s.Assembly("Services");
        s.Assembly("Service.Contracts");
        s.Assembly("Repository");
        s.Assembly("Repository.Contracts");
    });

});


var app = builder.Build();

// Configure the HTTP request pipeline.
if( !app.Environment.IsDevelopment() )
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
