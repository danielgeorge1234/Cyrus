﻿using System.ComponentModel.DataAnnotations;

namespace CyrusCRM.Models
{
    public class CreateRoleViewModel
    {
        [Required]

        public string RoleName { get; set; }



    }
}
