﻿using System;
using System.Threading.Tasks;
using CyrusCRM;
using Domain.Contracts;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using Repository.Contracts.Contracts;
using Repository.Repositories;

public class UnitOfWork : IUnitOfWork
{
    private readonly ApplicationDbContext _context;
    private bool _disposed = false;
    private IDbContextTransaction _transaction;

    public UnitOfWork(ApplicationDbContext context)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
    }

    public IGenericRepository<T> Repository<T>() where T : class
    {
        return new GenericRepository<T>(_context);
    }

    public async Task<int> CompleteAsync()
    {
        try
        {
            return await _context.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException ex)
        {
            // Handle concurrency exception
            throw new Exception("Concurrency error occurred while saving changes.", ex);
        }
        catch (DbUpdateException ex)
        {
            // Handle other update exceptions
            throw new Exception("Error occurred while saving changes.", ex);
        }
        catch (Exception ex)
        {
            // Handle other exceptions
            throw new Exception("An error occurred while saving changes.", ex);
        }
    }

    public async Task CreateTransactionAsync()
    {
        if (_transaction != null)
        {
            throw new InvalidOperationException("A transaction is already active.");
        }

        _transaction = await _context.Database.BeginTransactionAsync();
    }

    public async Task CommitAsync()
    {
        if (_transaction == null)
        {
            throw new InvalidOperationException("No transaction is active to commit.");
        }

        try
        {
            await _context.Database.CurrentTransaction.CommitAsync();
        }
        catch
        {
            await RollbackAsync();
            throw; 
        }
        finally
        {
            _transaction.Dispose();
            _transaction = null;
        }
    }

    public async Task RollbackAsync()
    {
        if (_transaction == null)
        {
            throw new InvalidOperationException("No transaction is active to rollback.");
        }

        try
        {
            await _context.Database.CurrentTransaction.RollbackAsync();
        }
        finally
        {
            _transaction.Dispose();
            _transaction = null;
        }
    }

    protected virtual void Dispose(bool disposing)
    {
        if (!_disposed)
        {
            if (disposing)
            {
                _transaction?.Dispose();
                _context.Dispose();
            }
            _disposed = true;
        }
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    Task IUnitOfWork.SaveChangesAsync()
    {
        return _context.SaveChangesAsync();
    }
}
