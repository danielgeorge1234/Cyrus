﻿using CairoCathInventorySystem.Domain.Models.Base;
using CyrusCRM;
using FluentNHibernate.Data;
using Microsoft.EntityFrameworkCore;
using NHibernate.Criterion;
using Repository.Contracts.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Repositories
{
    public class GenericRepository<T> : IGenericRepository<T> where T : class

    {

        private readonly ApplicationDbContext _dbContext;
        private readonly DbSet<T> _dbSet;
        public GenericRepository(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
            _dbSet = _dbContext.Set<T>();
        }

        public async Task AddAsync(T entity)
        {
            await _dbSet.AddAsync(entity);

            await _dbContext.SaveChangesAsync();
        }

        public void Delete(T entity)
        {
            _dbSet.Remove(entity);
        }



        public async Task<IEnumerable<T>> GetAllAsync()
        {
            return await _dbSet.ToListAsync();
        }

        public async Task<T> GetByConditionAsync(Expression<Func<T, bool>> predicate, params string[] includes)
        {
            var entity = _dbSet.AsQueryable();
            if(includes.Count()>0)
                entity = includes.Aggregate(entity,(current,include) => current.Include(include));
            return await entity.Where(predicate).FirstOrDefaultAsync();
        }

      
        public async Task<T> GetByIdAsync(int id, params string[] includes)
        {
            return await _dbSet.Where(obj => (obj as BaseEntity).Id == id).FirstOrDefaultAsync();
        }

        public async Task<(int Total, IEnumerable<T> Entities)> GetPaginatedAsync(int PageNumber, int PageSize, Expression<Func<T, bool>>? predicate = null, params string[] includes)
        {
            var entities = _dbContext.Set<T>().AsQueryable();
            if( includes.Count() > 0 )
            {
                entities = includes.Aggregate(entities,
                          (current,include) => current.Include(include));
            }
            if( predicate == null )
            {
                var resultWithoutPred = await entities.Skip(PageNumber * PageSize).Take(PageSize).ToListAsync();
                var totalWithoutPred = await entities.CountAsync();
                return (totalWithoutPred, resultWithoutPred);
            }
            var resultWithPred =  await entities.Where(predicate).Skip(PageNumber * PageSize).Take(PageSize).ToListAsync();
            var totalWithPred = await entities.Where(predicate).CountAsync();
            return (totalWithPred, resultWithPred);
        }

        public async Task<IEnumerable<T>> GetsByConditionAsync(Expression<Func<T, bool>> predicate, params string[] includes)
        {
            return await _dbSet.Where(predicate).ToListAsync();
        }

        public void Update(T entity)
        {
            _dbSet.Update(entity);
            _dbContext.SaveChanges();
        }


    }
}
