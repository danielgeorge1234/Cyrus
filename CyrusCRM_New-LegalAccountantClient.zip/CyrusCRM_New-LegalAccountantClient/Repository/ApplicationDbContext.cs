﻿using CyrusCRM.Areas.CRM.Models;
using Domain;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace CyrusCRM
{
    public partial class ApplicationDbContext : IdentityDbContext
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options,
            IHttpContextAccessor httpContextAccessor)
            : base(options)
        {
            _httpContextAccessor = httpContextAccessor;
        }


        public DbSet<Client> Clients { get; set; }
        public DbSet<Lead> Leads { get; set; }
        public DbSet<LeadHistory> LeadHistories { get; set; }
        public DbSet<ClientContact> ClientContacts { get; set; }
        public DbSet<ApplicationUser> ApplicationUsers { get; set; }
        public DbSet<LegalAccountant> LegalAccountants { get; set; }
        public DbSet<Stages> Stages { get; set; }
        public DbSet<Ticket> Tickets { get; set; }
        public DbSet<EInvoice> EInvoices { get; set; }
        public DbSet<Contract> Contracts { get; set; }
        public DbSet<Meeting> Meetings { get; set; }
        public DbSet<PaymentHistory> PaymentHistories { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<TicketHistory> TicketHistories { get; set; }




    }
}