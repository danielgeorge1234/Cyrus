﻿using CairoCathInventorySystem.Domain.Models.Base;
using CyrusCRM.Areas.CRM.Models;
using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyModel;
using System.Reflection;
using System.Reflection.Emit;

namespace CyrusCRM
{
    public partial class ApplicationDbContext
    {
        protected override void OnModelCreating(ModelBuilder builder)
        {

            foreach( var type in GetEntityTypes() )
            {
                var method = SetGlobalQueryMethod.MakeGenericMethod(type);
                method.Invoke(this,new object[] { builder });
            }

            builder.Entity<Client>()
         .Property(c => c.IsClient)
         .IsRequired()
         .HasDefaultValue(false);


            builder.Entity<Stages>().HasData(
                new Stages() { Id = 1,Name = "المرحلة الاولى" },
                new Stages() { Id = 2,Name = "المرحلة الثانية" },
                new Stages() { Id = 3,Name = "المرحلة الثالثة" },
                new Stages() { Id = 4,Name = "المرحلة الرابعة" });
            builder.Entity<LegalAccountant>().HasIndex(ob => ob.Phone).IsUnique();

            builder.Entity<Ticket>()
            .HasOne(t => t.Product)
            .WithMany()
            .HasForeignKey(t => t.ProductId)
            .OnDelete(DeleteBehavior.Restrict); // Specify appropriate behavior

            // Configure Ticket to Client relationship
            builder.Entity<Ticket>()
                .HasOne(t => t.Client)
                .WithMany()
                .HasForeignKey(t => t.ClientId)
                .OnDelete(DeleteBehavior.NoAction); // Specify appropriate behavior

            // Configure Contract to Lead relationship
            builder.Entity<Contract>()
                .HasOne(c => c.Lead)
                .WithMany()
                .HasForeignKey(c => c.LeadId)
                .OnDelete(DeleteBehavior.Restrict); // Specify appropriate behavior

            // Configure Contract to Client relationship
            builder.Entity<Contract>()
                .HasOne(c => c.Client)
                .WithMany()
                .HasForeignKey(c => c.ClientId)
                .OnDelete(DeleteBehavior.NoAction); // Specify appropriate behavior

            base.OnModelCreating(builder);


        }

        public void SetGlobalQuery<T>(ModelBuilder builder) where T : BaseEntity
        {
            builder.Entity<T>().HasKey(e => e.Id);
            builder.Entity<T>().HasQueryFilter(e => !e.IsDeleted);
            
        }

    

        static readonly MethodInfo SetGlobalQueryMethod =
        typeof(ApplicationDbContext)
        .GetMethods(BindingFlags.Public |
            BindingFlags.Instance)
        .Single(t => t.IsGenericMethod && t.Name == "SetGlobalQuery");

       


        private static IList<Type> _entityTypeCache;
        private static IList<Type> GetEntityTypes()
        {
            if( _entityTypeCache != null )
            {
                return _entityTypeCache.ToList();
            }

            _entityTypeCache = ( from a in GetReferencingAssemblies()
                                 from t in a.DefinedTypes
                                 where t.BaseType == typeof(BaseEntity)
                                 select t.AsType() ).ToList();

            return _entityTypeCache;
        }

  
        private static IEnumerable<Assembly> GetReferencingAssemblies()
        {
            var assemblies = new List<Assembly>();
            var dependencies = DependencyContext.Default.RuntimeLibraries;

            foreach( var library in dependencies )
            {
                try
                {
                    var assembly = Assembly.Load(new AssemblyName(library.Name));
                    assemblies.Add(assembly);
                }
                catch( FileNotFoundException )
                { }
            }
            return assemblies;
        }
        private string GetLoggedInEmployeeUserName()
        {
            var httpContext = _httpContextAccessor.HttpContext;
            if( httpContext != null )
            {
                if( httpContext.User != null )
                {
                    var user = httpContext.User.Identity;
                    if( user != null )
                    {
                        var userIdStr = user.Name;
                        return userIdStr;
                    }
                }
            }
            return null;
        }
        private void OnBeforeSaving()
        {
            var entries = ChangeTracker.Entries();
            foreach( var entry in entries )
            {
                if( entry.Entity is BaseEntity trackable )
                {
                    var now = DateTime.UtcNow;
                    var userName = GetLoggedInEmployeeUserName();
                    switch( entry.State )
                    {
                        case EntityState.Modified:
                            trackable.LastModified = now;
                            trackable.ModifiedBy = userName;
                            break;

                        case EntityState.Added:
                            trackable.DateCreated = now;
                            trackable.LastModified = now;
                            trackable.IsDeleted = false;
                            trackable.ModifiedBy = userName;
                            trackable.CreatedBy = userName;
                            break;
                        case EntityState.Deleted:
                            entry.State = EntityState.Modified;
                            trackable.ModifiedBy = userName;
                            trackable.LastModified = now;
                            trackable.IsDeleted = true;
                            break;
                    }
                }

                if( entry.Entity is ComplexKeyBaseEntity trackableString )
                {
                    var now = DateTime.UtcNow;
                    var userId = GetLoggedInEmployeeUserName();
                    switch( entry.State )
                    {
                        case EntityState.Modified:
                            trackableString.LastModified = now;
                            trackableString.ModifiedBy = userId;
                            break;

                        case EntityState.Added:
                            trackableString.DateCreated = now;
                            trackableString.LastModified = now;
                            trackableString.IsDeleted = false;
                            trackableString.ModifiedBy = userId;
                            trackableString.CreatedBy = userId;
                            break;
                        case EntityState.Deleted:
                            entry.State = EntityState.Modified;
                            trackableString.ModifiedBy = userId;
                            trackableString.LastModified = now;
                            trackableString.IsDeleted = true;
                            break;
                    }
                }
            }
        }
        public override int SaveChanges()
        {
            OnBeforeSaving();
            return base.SaveChanges();
        }
        public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            OnBeforeSaving();
            return base.SaveChangesAsync(cancellationToken);
        }



    }
}
