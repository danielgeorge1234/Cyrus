﻿using CairoCathInventorySystem.Domain.Models.Base;
using CyrusCRM.Areas.CRM.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Domain
{
    public class Contract : BaseEntity
    {

        [Required]
        public Lead Lead { get; set; }
        [ForeignKey(nameof(Lead))]
        public int LeadId { get; set; }
        public Client Client { get; set; }
        [ForeignKey(nameof(Client))]
        public int ClientId { get; set; }
    }
}
