﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using CairoCathInventorySystem.Domain.Models.Base;

namespace CyrusCRM.Areas.CRM.Models
{
    public class Stages : BaseEntity
    {
        [Required]
        [StringLength(100)]
        [DisplayName("اسم المرحلة")]
        public string Name { get; set; }
    }
}
