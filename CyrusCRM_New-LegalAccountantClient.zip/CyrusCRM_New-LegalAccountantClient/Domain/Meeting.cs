﻿using CairoCathInventorySystem.Domain.Models.Base;
using CyrusCRM.Areas.CRM.Models;
using System.ComponentModel.DataAnnotations.Schema;

namespace Domain
{
    public class Meeting : BaseEntity
    {
        public Lead Lead { get; set; }
        [ForeignKey(nameof(Lead))]
        public int LeadId { get; set; }
        public string UserId { get; set; }
        [ForeignKey(nameof(UserId))]
        public ApplicationUser User { get; set; }
    }
}
