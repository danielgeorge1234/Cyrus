﻿namespace Domain.Enums
{
    public enum LeadStatus
    {
        NoAnswer = 0,
        FollowUp = 1,
        Meeting = 2,
        Sale = 3,
        Finished = 4,
        ShortList = 5,
        Installation = 6,
        Visited = 7,
        Published = 8,
    }
}
