﻿using CairoCathInventorySystem.Domain.Models.Base;
using Repository.Contracts.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Contracts
{
    public interface IUnitOfWork:IDisposable
    {
        IGenericRepository<TEntity> Repository<TEntity>() where TEntity : class;
        
        Task CreateTransactionAsync();
        Task CommitAsync();
        Task RollbackAsync();

        Task SaveChangesAsync();



    }
}
