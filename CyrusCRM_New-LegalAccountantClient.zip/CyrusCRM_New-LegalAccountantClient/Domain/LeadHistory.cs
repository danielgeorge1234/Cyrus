﻿using CairoCathInventorySystem.Domain.Models.Base;
using Domain.Enums;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CyrusCRM.Areas.CRM.Models
{
    [Table("CRM_LeadHistory")]
    public class LeadHistory : BaseEntity
    {
        public int LeadId { get; set; }

        public Lead Lead { get; set; }

        [Required]
        public string Comment { get; set; }
        public ServiceType CommentType { get; set; }

        public DateTime CommentDateTime { get; set; }
    }
}
