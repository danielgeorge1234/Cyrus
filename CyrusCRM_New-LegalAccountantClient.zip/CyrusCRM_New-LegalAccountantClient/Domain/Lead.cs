﻿using CairoCathInventorySystem.Domain.Models.Base;
using Domain;
using Domain.Enums;
using System.ComponentModel.DataAnnotations.Schema;

namespace CyrusCRM.Areas.CRM.Models
{
    [Table("CRM_Lead")]
    public class Lead : BaseEntity
    {
      

        public string UserName { get; set; }
        public ServiceType LeadType { get; set; }
        public LeadStatus LeadStatus { get; set; }

        public DateTime? FollowUpDateTime { get; set; }

        public DateTime? MeetingDateTime { get; set; }


        public int ClientId { get; set; }

        [ForeignKey(nameof(ClientId))]
        public Client Client { get; set; }

        public int ProductId { get; set; }

        [ForeignKey(nameof(ProductId))]
        public Product Product { get; set; }
        public Contract Contract { get; set; }

    }
}
