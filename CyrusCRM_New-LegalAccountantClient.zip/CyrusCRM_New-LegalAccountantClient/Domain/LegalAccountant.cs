﻿using CairoCathInventorySystem.Domain.Models.Base;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CyrusCRM.Areas.CRM.Models
{
    public class LegalAccountant : BaseEntity
    {
        [Required]
        [StringLength(100)]
        [DisplayName("اسم المحاسب القانونى")]
        public string Name { get; set; }

        [StringLength(50)]
        [RegularExpression("^[0-9]*$",ErrorMessage = "Only Numbers")]
        [DisplayName("تليفون المحاسب القانونى")]
        public string Phone { get; set; }
    }
}
