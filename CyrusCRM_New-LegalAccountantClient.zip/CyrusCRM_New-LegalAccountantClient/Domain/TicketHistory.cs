﻿using CairoCathInventorySystem.Domain.Models.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    public class TicketHistory:BaseEntity
    {
        public Ticket Ticket { get; set; }
        [ForeignKey(nameof(Ticket))]
        public int TicketId { get; set; }
    }
}
