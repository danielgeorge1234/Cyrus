﻿using CairoCathInventorySystem.Domain.Models.Base;
using Domain.Enums;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;

namespace Domain
{
    public class Ticket : BaseEntity
    {

        public TicketStatus TicketStatus { get; set; }

        public Product Product { get; set; }
        [ForeignKey(nameof(Contract))]

        public int ProductId { get; set; }
        public Client Client { get; set; }
        [ForeignKey(nameof(Client))]
        public int ClientId { get; set; }
        public string UserId { get; set; }
        [ForeignKey(nameof(UserId))]
        public ApplicationUser User { get; set; }
    }
}
