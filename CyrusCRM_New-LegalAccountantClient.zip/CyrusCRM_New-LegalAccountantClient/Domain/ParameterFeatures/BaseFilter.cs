﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.ParameterFeatures
{
    public abstract class BaseFilter
    {
        private int _maxPageSize = 100;
        private int _pageSize = 10;
        private int _pageNumber = 0;

        public int PageSize
        {
            set
            {
                _pageSize = value > _maxPageSize ? _maxPageSize : value == 0 ? _pageSize : value;
            }
            get { return _pageSize; }
        }
        public int PageNumber
        {
            set
            {
                _pageNumber = value <= 1 ? 0 : value - 1;
            }
            get { return _pageNumber; }
        }

    }


}

