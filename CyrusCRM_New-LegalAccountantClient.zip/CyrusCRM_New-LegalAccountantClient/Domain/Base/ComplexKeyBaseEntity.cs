﻿namespace CairoCathInventorySystem.Domain.Models.Base
{
    public class ComplexKeyBaseEntity : IBaseEntity
    {
        public DateTime DateCreated { get; set; }
        public DateTime LastModified { get; set; }
        public string? CreatedBy { get; set; }
        public string? ModifiedBy { get; set; }
        public bool IsDeleted { get; set; } = default;
    }
}
