﻿using CairoCathInventorySystem.Domain.Models.Base;
using CyrusCRM.Areas.CRM.Models;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;
using System.Text.Json.Serialization;

namespace Domain
{
    [Table("CRM_Client")]
    public class Client : BaseEntity, IEqualityComparer<Client>
    {
        [Required]
        [StringLength(100)]
        [DisplayName("اسم العميل")]
        public string Name { get; set; }

        [Required]
        [StringLength(15)]
        [DisplayName("السجل الضريبى")]
        public string TaxCard { get; set; }

        [StringLength(50)]
        [RegularExpression("^[0-9]*$",ErrorMessage = "Only Numbers")]
        [DisplayName("تليفون 1")]
        public string Phone1 { get; set; }

        [StringLength(50)]
        [RegularExpression("^[0-9]*$",ErrorMessage = "Only Numbers")]
        [DisplayName("تليفون 2")]
        public string Phone2 { get; set; }

        [StringLength(50)]
        [RegularExpression("^[0-9]*$",ErrorMessage = "Only Numbers")]
        [DisplayName("تليفون 3")]
        public string Phone3 { get; set; }

        [StringLength(50)]
        [DataType(DataType.EmailAddress)]
        [DisplayName("البريد الالكترونى")]
        public string Email { get; set; }

        [StringLength(150)]
        [DisplayName("المحافظة")]
        public string Governate { get; set; }

        [StringLength(150)]
        [DisplayName("الحى")]
        public string District { get; set; }

        [StringLength(150)]
        [DisplayName("العنوان")]
        public string Address { get; set; }

        [StringLength(255)]
        [DisplayName("النشاط التجارى")]
        public string Domain { get; set; }

        [ForeignKey("StageId")]
        public Stages Stages { get; set; }

        public int? StageId { get; set; }

        [ForeignKey("LegalAccountantId")]
        public LegalAccountant? LegalAccountant { get; set; }

        public int? LegalAccountantId { get; set; }

        public bool FollowUp { get; set; }


        public string? UserId { get; set; }
        [ForeignKey(nameof(UserId))]
        public ApplicationUser? ApplicationUser { get; set; }

        [JsonIgnore]
        public ICollection<Lead> Leads { get; set; }

        public bool IsClient { get; set; }

        public bool Equals(Client x,Client y)
        {
            if( decimal.TryParse(x.TaxCard,out var result) && decimal.TryParse(y.TaxCard,out result) )
            {
                return decimal.Parse(x.TaxCard) == decimal.Parse(y.TaxCard);
            }
            throw new Exception("هناك خطا فى السجل الضريبى");
        }

        public int GetHashCode([DisallowNull] Client obj)
        {
            return HashCode.Combine(obj.TaxCard,obj.Phone1);
        }
    }

    public class ClientEqualityComparer : IEqualityComparer<Client>
    {
        public bool Equals(Client x,Client y)
        {
            if( decimal.TryParse(x.TaxCard,out var result) && decimal.TryParse(y.TaxCard,out result) )
            {
                return decimal.Parse(x.TaxCard) == decimal.Parse(y.TaxCard);
            }
            throw new Exception("هناك خطا فى السجل الضريبى");
        }

        public int GetHashCode([DisallowNull] Client obj)
        {
            return HashCode.Combine(obj.TaxCard,obj.Phone1);
        }
    }
}
