﻿using Service.Contracts.Dtos.LegalAccountantDto;
using Service.Contracts.Dtos.StagesDto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service.Contracts.Managers
{
    public interface IStagesManager
    {

        Task<IEnumerable<StagesDto>> GeAllStagesDtoAsync();
        Task<StagesDto> GetStagesByIdAsync(int id);
        Task AddStagesAsync(StagesDto stagesDto);
        Task UpdateStagesAsync(StagesDto stagesDto);
        Task DeleteStagesAsync(int id);



    }
}
