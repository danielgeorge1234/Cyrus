﻿using Domain.Dtos.ClientDto;
using Domain.ParameterFeatures;
using Service.Contracts.Pagination;

namespace Service.Contracts.Managers
{
    public interface IClientManager
    {

        Task<IEnumerable<ClientDto>> GetClientsAsync();
        Task<ClientDto> GetClientByIdAsync(int id);
        Task AddClientAsync(ClientDto client);
        Task UpdateClientAsync(ClientDto client);
        Task DeleteClientAsync(int id);
        Task<PaginatedList<ClientDto>> GetClientsPaginatedAsync(ClientFilter filter);



    }
}
