﻿using Domain.Dtos.ClientDto;
using Service.Contracts.Dtos.LeadDto;

namespace Service.Contracts.Managers
{
    public interface ILeadManager
    {


        Task<IEnumerable<LeadDto>> GetLeadsAsync();
        Task<LeadDto> GetLeadByIdAsync(int id);
        Task AddLeadAsync(LeadDto lead);
        Task UpdateLeadAsync(LeadDto lead);
        Task DeleteLeadAsync(int id);



    }
}
