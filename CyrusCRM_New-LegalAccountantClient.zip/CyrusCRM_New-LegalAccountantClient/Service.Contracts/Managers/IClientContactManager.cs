﻿using Domain;
using Service.Contracts.Dtos.ClientContactDto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service.Contracts.Managers
{
    public interface IClientContactManager
    {
        Task<IEnumerable<ClientContactDto>> GetAllClientContactsAsync();
        Task<ClientContactDto> GetClientContactByIdAsync(int id);
        Task AddClientContactAsync(ClientContactDto clientContact);
        Task UpdateClientContactAsync(ClientContactDto clientContact);
        Task DeleteClientContactAsync(int id);

    }
}
