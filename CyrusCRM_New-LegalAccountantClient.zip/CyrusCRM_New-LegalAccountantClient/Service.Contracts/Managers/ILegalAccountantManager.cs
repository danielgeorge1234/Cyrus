﻿using Service.Contracts.Dtos.LeadDto;
using Service.Contracts.Dtos.LegalAccountantDto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service.Contracts.Managers
{
    public interface ILegalAccountantManager
    {
        Task<IEnumerable<LegalAccountantDto>> GeAllLegalAccountantAsync();
        Task<LegalAccountantDto> GetLegalAccountByIdAsync(int id);
        Task AddLegalAccountantAsync(LegalAccountantDto legalAccountant);
        Task UpdateLegalAccountantAsync(LegalAccountantDto legalAccountant);
        Task DeleteLegalAccountantAsync(int id);



    }
}
