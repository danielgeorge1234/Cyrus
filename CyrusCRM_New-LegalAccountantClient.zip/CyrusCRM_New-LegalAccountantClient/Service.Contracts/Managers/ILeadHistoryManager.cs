﻿using Service.Contracts.Dtos.ClientContactDto;
using Service.Contracts.Dtos.LeadHistoryDto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service.Contracts.Managers
{
    public interface ILeadHistoryManager
    {
        Task<IEnumerable<LeadHistoryDto>> GetAllLeadHistorysAsync();
        Task<LeadHistoryDto> GetLeadHistoryByIdAsync(int id);
        Task AddLeadHistoryAsync(LeadHistoryDto leadHistory);
        Task UpdateLeadHistoryAsync(LeadHistoryDto leadHistory);
        Task DeleteLeadHistoryAsync(int id);





    }
}
