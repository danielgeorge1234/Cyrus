﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service.Contracts.Managers
{
    public interface IServiceManager
    {
        public IClientManager ClientManager { get; }

        public IClientContactManager ClientContactManager { get; }

        public ILeadManager leadManager { get; }


        public ILeadHistoryManager leadHistoryManager { get; }  


        public ILegalAccountantManager legalAccountantManager { get; }

        public IStagesManager stagesManager { get; }




    }
}
