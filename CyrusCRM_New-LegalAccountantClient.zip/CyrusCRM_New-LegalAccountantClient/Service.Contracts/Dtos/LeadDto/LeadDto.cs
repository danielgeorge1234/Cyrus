﻿using CyrusCRM.Areas.CRM.Models;
using Domain.Enums;
using Domain;
using Service.Contracts.Dtos.BaseDto;
using Service.Contracts.Mapping;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service.Contracts.Dtos.LeadDto
{
    public class LeadDto : BaseIdDto, IMapFrom<Lead>
    {

        public string UserName { get; set; }
        public ServiceType LeadType { get; set; }
        public LeadStatus LeadStatus { get; set; }

        public DateTime? FollowUpDateTime { get; set; }

        public DateTime? MeetingDateTime { get; set; }


        public int ClientId { get; set; }

        //public Client Client { get; set; }

        //public int ProductId { get; set; }

        //public Product Product { get; set; }


    }
}
