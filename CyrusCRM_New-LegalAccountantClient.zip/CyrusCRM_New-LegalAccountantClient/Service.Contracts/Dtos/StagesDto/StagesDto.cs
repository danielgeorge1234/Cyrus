﻿using CyrusCRM.Areas.CRM.Models;
using Service.Contracts.Dtos.BaseDto;
using Service.Contracts.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service.Contracts.Dtos.StagesDto
{
    public class StagesDto:BaseIdDto,IMapFrom<Stages>
    {
        public string Name { get; set; }



    }
}
