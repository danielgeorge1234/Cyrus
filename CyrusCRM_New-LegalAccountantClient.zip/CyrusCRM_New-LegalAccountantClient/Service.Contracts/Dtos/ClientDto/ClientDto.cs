﻿using CyrusCRM.Areas.CRM.Models;
using Service.Contracts.Dtos.BaseDto;
using Service.Contracts.Mapping;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Domain.Dtos.ClientDto
{
    public class ClientDto : BaseIdDto, IMapFrom<Client>
    {
        [Required]
        [StringLength(100)]
        [DisplayName("اسم العميل")]
        public string Name { get; set; }

        [Required]
        [StringLength(15)]
        [DisplayName("السجل الضريبى")]
        public string TaxCard { get; set; }

        [StringLength(50)]
        [RegularExpression("^[0-9]*$", ErrorMessage = "Only Numbers")]
        [DisplayName("تليفون 1")]
        public string Phone1 { get; set; }

        [StringLength(50)]
        [RegularExpression("^[0-9]*$", ErrorMessage = "Only Numbers")]
        [DisplayName("تليفون 2")]
        public string Phone2 { get; set; }

        [StringLength(50)]
        [RegularExpression("^[0-9]*$", ErrorMessage = "Only Numbers")]
        [DisplayName("تليفون 3")]
        public string Phone3 { get; set; }

        [StringLength(50)]
        [DataType(DataType.EmailAddress)]
        [DisplayName("البريد الالكترونى")]
        public string Email { get; set; }

        [StringLength(150)]
        [DisplayName("المحافظة")]
        public string Governate { get; set; }

        [StringLength(150)]
        [DisplayName("الحى")]
        public string? District { get; set; }
        [StringLength(150)]
        [DisplayName("العنوان")]
        public string? Address { get; set; }

        [StringLength(255)]
        [DisplayName("النشاط التجارى")]
        public string Domain { get; set; } = string.Empty;

        public Stages? Stages { get; set; }

        public int? StageId { get; set; }
        //public string? UserId { get; set; }
        public ApplicationUser? ApplicationUser { get; set; }

        [ForeignKey("LegalAccountantId")]
        public LegalAccountant? LegalAccountant { get; set; }

        public int? LegalAccountantId { get; set; }


    }
}
