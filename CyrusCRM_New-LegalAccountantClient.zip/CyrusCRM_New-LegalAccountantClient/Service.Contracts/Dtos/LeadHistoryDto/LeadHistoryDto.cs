﻿using CyrusCRM.Areas.CRM.Models;
using Domain.Enums;
using Service.Contracts.Dtos.BaseDto;
using Service.Contracts.Mapping;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service.Contracts.Dtos.LeadHistoryDto
{
    public class LeadHistoryDto:BaseIdDto,IMapFrom<LeadHistory>
    {

        public int LeadId { get; set; }

        //public Lead Lead { get; set; }

        public string Comment { get; set; }
        public ServiceType CommentType { get; set; }

        public DateTime CommentDateTime { get; set; }

    }
}
