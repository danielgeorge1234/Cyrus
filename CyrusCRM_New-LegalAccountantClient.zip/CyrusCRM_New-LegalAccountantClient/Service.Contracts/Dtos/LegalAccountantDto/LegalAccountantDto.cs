﻿using CyrusCRM.Areas.CRM.Models;
using Service.Contracts.Dtos.BaseDto;
using Service.Contracts.Mapping;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domain;

namespace Service.Contracts.Dtos.LegalAccountantDto
{
    public class LegalAccountantDto : BaseIdDto, IMapFrom<LegalAccountant>
    {

        [Required]
        [StringLength(100)]
        [DisplayName("اسم المحاسب القانونى")]
        public string Name { get; set; }

        [StringLength(50)]
        [RegularExpression("^[0-9]*$", ErrorMessage = "Only Numbers")]
        [DisplayName("تليفون المحاسب القانونى")]
        public string Phone { get; set; }

        public int ClientId { get; set; }

        public Client? Client { get; set; }


    }
}
