﻿using Domain;
using Service.Contracts.Dtos.BaseDto;
using Service.Contracts.Mapping;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service.Contracts.Dtos.ClientContactDto
{
    public class ClientContactDto:BaseIdDto,IMapFrom<ClientContact>
    {

        public int ClientId { get; set; }

        //public Client Client { get; set; }

        
        public string Name { get; set; }

        public string Position { get; set; }


        [StringLength(50)]
        [RegularExpression("^[0-9]*$", ErrorMessage = "Only Numbers")]
        public string Phone1 { get; set; }


        [StringLength(50)]
        [RegularExpression("^[0-9]*$", ErrorMessage = "Only Numbers")]
        public string Phone2 { get; set; }


        [StringLength(50)]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }


    }
}
