﻿using AutoMapper;

namespace Service.Contracts.Mapping
{
    public interface IHaveCustomMappings
    {
        void CreateMapping(Profile configuration);
    }
}
