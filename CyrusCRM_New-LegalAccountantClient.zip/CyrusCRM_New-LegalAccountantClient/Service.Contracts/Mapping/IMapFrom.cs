﻿namespace Service.Contracts.Mapping
{
    public interface IMapFrom<T>
    {
    }
}
