﻿namespace Service.Contracts.Pagination
{
    public class PaginatedList<T> : List<T>
    {
        public MetaData MetaData { get; set; }
        public List<T> Data { get; set; }
        PaginatedList(List<T> items,int count,int pageNumber,int pageSize)
        {
            MetaData = new MetaData()
            {
                CurrentCount = items.Count,
                TotalCount = count,
                PageSize = pageSize,
                CurrentPage = pageNumber + 1,
                TotalPages = (int)Math.Ceiling(count / (double)pageSize),
            };
            Data = items;
        }
        public static PaginatedList<T> Create(IEnumerable<T> items,int count,int pageNumber,int pageSize)
        {
            return new PaginatedList<T>(items.ToList(),count,pageNumber,pageSize);   
        }
    }
}