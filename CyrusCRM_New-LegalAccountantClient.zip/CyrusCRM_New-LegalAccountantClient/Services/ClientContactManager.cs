﻿using AutoMapper;
using Domain;
using Domain.Contracts;
using Service.Contracts.Dtos.ClientContactDto;
using Service.Contracts.Managers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class ClientContactManager:IClientContactManager
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public ClientContactManager(IUnitOfWork unitOfWork , IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public async Task AddClientContactAsync(ClientContactDto clientContactDto)
        {
            if (clientContactDto == null)
            {
                throw new ArgumentNullException(nameof(clientContactDto));
            }

            var clientContactEntity = _mapper.Map<ClientContact>(clientContactDto);

           await _unitOfWork.Repository<ClientContact>().AddAsync(clientContactEntity);
            await _unitOfWork.SaveChangesAsync();
        }

        public async Task DeleteClientContactAsync(int id)
        {
            var clientContact = await _unitOfWork.Repository<ClientContact>().GetByIdAsync(id);
            if (clientContact != null)
            {
                _unitOfWork.Repository<ClientContact>().Delete(clientContact);
                await _unitOfWork.SaveChangesAsync();
            }
        }

        public async Task<IEnumerable<ClientContactDto>> GetAllClientContactsAsync()
        {
            var clientContacts = await _unitOfWork.Repository<ClientContact>().GetAllAsync();
            return _mapper.Map<IEnumerable<ClientContactDto>>(clientContacts);
        }

        public async Task<ClientContactDto> GetClientContactByIdAsync(int id)
        {
            var clientContact = await _unitOfWork.Repository<ClientContact>().GetByIdAsync(id);
            return _mapper.Map<ClientContactDto>(clientContact);
        }

  

        public async Task UpdateClientContactAsync(ClientContactDto clientContactDto)
        {
            if (clientContactDto == null)
            {
                throw new ArgumentNullException(nameof(clientContactDto));
            }

            var existingClientContact = await _unitOfWork.Repository<ClientContact>().GetByIdAsync(clientContactDto.Id);
            if (existingClientContact == null)
            {
                throw new ArgumentException($"ClientContact with ID {clientContactDto.Id} not found.");
            }

            _mapper.Map(clientContactDto, existingClientContact);

            _unitOfWork.Repository<ClientContact>().Update(existingClientContact);
            await _unitOfWork.SaveChangesAsync();
        }





    }
}
