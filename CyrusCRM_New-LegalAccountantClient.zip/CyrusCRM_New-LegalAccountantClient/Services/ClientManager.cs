﻿using AutoMapper;
using Domain;
using Domain.Contracts;
using Domain.Dtos.ClientDto;
using Domain.ParameterFeatures;
using Service.Contracts.Managers;
using Service.Contracts.Pagination;

namespace Services
{
    public class ClientManager : IClientManager
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public ClientManager(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public async Task AddClientAsync(ClientDto clientDto)
        {
            if (clientDto == null)
            {
                throw new ArgumentNullException(nameof(clientDto));
            }

            var clientEntity = _mapper.Map<Client>(clientDto);

            await _unitOfWork.Repository<Client>().AddAsync(clientEntity);
            await _unitOfWork.SaveChangesAsync();
        }

        public async Task DeleteClientAsync(int id)
        {
            var client = await _unitOfWork.Repository<Client>().GetByIdAsync(id);
            if (client != null)
            {
                _unitOfWork.Repository<Client>().Delete(client);
                await _unitOfWork.SaveChangesAsync();
            }
        }

        public async Task<ClientDto> GetClientByIdAsync(int id)
        {
            var client = await _unitOfWork.Repository<Client>().GetByIdAsync(id);
            return _mapper.Map<ClientDto>(client);
        }

        public async Task<IEnumerable<ClientDto>> GetClientsAsync()
        {
            var clients = await _unitOfWork.Repository<Client>().GetAllAsync();
            return _mapper.Map<IEnumerable<ClientDto>>(clients);
        }

        public async Task<PaginatedList<ClientDto>> GetClientsPaginatedAsync(ClientFilter filter)
        {
            var clients = await _unitOfWork.Repository<Client>().GetPaginatedAsync(filter.PageNumber,filter.PageSize);
            var clientDtos = _mapper.Map<IEnumerable<ClientDto>>(clients.Entities);
            return PaginatedList<ClientDto>.Create(clientDtos,clients.Total, filter.PageNumber, filter.PageSize);
        }


        public async Task UpdateClientAsync(ClientDto clientDto)
        {
            if (clientDto == null)
            {
                throw new ArgumentNullException(nameof(clientDto));
            }

            var existingClient = await _unitOfWork.Repository<Client>().GetByIdAsync(clientDto.Id);
            if (existingClient == null)
            {
                throw new ArgumentException($"Client with ID {clientDto.Id} not found.");
            }

            _mapper.Map(clientDto, existingClient);

            _unitOfWork.Repository<Client>().Update(existingClient);
            await _unitOfWork.SaveChangesAsync();
        }
    }
}
