﻿using AutoMapper;
using CyrusCRM.Areas.CRM.Models;
using Domain.Contracts;
using Service.Contracts.Managers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class ServiceManager : IServiceManager
    {



        private readonly Lazy<IClientManager> _clientManager;
        private readonly Lazy<IClientContactManager> _clientContactManager;
        private readonly Lazy<ILeadHistoryManager> _leadHistoryManager;
        private readonly Lazy<ILeadManager> _leadmanager;
        private readonly Lazy<ILegalAccountantManager> _legalAccountantManager;
        private readonly Lazy<IStagesManager> _stagesManager;


        public ServiceManager(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _clientManager = new Lazy<IClientManager>(() => new ClientManager(unitOfWork, mapper));
            _clientContactManager = new Lazy<IClientContactManager>(() => new ClientContactManager(unitOfWork, mapper));
            _leadHistoryManager = new Lazy<ILeadHistoryManager>(() => new LeadHistoryManager(unitOfWork, mapper));
            _stagesManager=new Lazy<IStagesManager>(() => new StagesManager(unitOfWork,mapper));
            _leadmanager = new Lazy<ILeadManager>(() => new LeadManager(unitOfWork, mapper));
            _legalAccountantManager = new Lazy<ILegalAccountantManager>(() => new LegalAccountantManager(unitOfWork, mapper));
        }


        public IClientManager ClientManager => _clientManager.Value;

        public IClientContactManager ClientContactManager => _clientContactManager.Value;

        public ILeadManager leadManager => _leadmanager.Value;

        public ILeadHistoryManager leadHistoryManager => _leadHistoryManager.Value;

        public ILegalAccountantManager legalAccountantManager => _legalAccountantManager.Value;

        public IStagesManager stagesManager => _stagesManager.Value;
    }
}
