﻿using AutoMapper;
using CyrusCRM.Areas.CRM.Models;
using Domain.Contracts;
using Service.Contracts.Dtos.LegalAccountantDto;
using Service.Contracts.Managers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class LegalAccountantManager:ILegalAccountantManager
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public LegalAccountantManager(IUnitOfWork unitOfWork,IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public async Task AddLegalAccountantAsync(LegalAccountantDto legalAccountantDto)
        {
            if (legalAccountantDto == null)
            {
                throw new ArgumentNullException(nameof(legalAccountantDto));
            }

            var legalAccountantEntity = _mapper.Map<LegalAccountant>(legalAccountantDto);

            await _unitOfWork.Repository<LegalAccountant>().AddAsync(legalAccountantEntity);
            await _unitOfWork.SaveChangesAsync();
        }

        public async Task DeleteLegalAccountantAsync(int id)
        {
            var legalAccountant = await _unitOfWork.Repository<LegalAccountant>().GetByIdAsync(id);
            if (legalAccountant != null)
            {
                _unitOfWork.Repository<LegalAccountant>().Delete(legalAccountant);
                await _unitOfWork.SaveChangesAsync();
            }
        }

        public async Task<IEnumerable<LegalAccountantDto>> GeAllLegalAccountantAsync()
        {
            var legalAccountants = await _unitOfWork.Repository<LegalAccountant>().GetAllAsync();
            return _mapper.Map<IEnumerable<LegalAccountantDto>>(legalAccountants);
        }

      

        public async Task<LegalAccountantDto> GetLegalAccountByIdAsync(int id)
        {
            var legalAccountant = await _unitOfWork.Repository<LegalAccountant>().GetByIdAsync(id);
            return _mapper.Map<LegalAccountantDto>(legalAccountant);

        }

        public async Task UpdateLegalAccountantAsync(LegalAccountantDto legalAccountantDto)
        {
            if (legalAccountantDto == null)
            {
                throw new ArgumentNullException(nameof(legalAccountantDto));
            }

            var existingLegalAccountant = await _unitOfWork.Repository<LegalAccountant>().GetByIdAsync(legalAccountantDto.Id);
            if (existingLegalAccountant == null)
            {
                throw new ArgumentException($"LegalAccountant with ID {legalAccountantDto.Id} not found.");
            }

            _mapper.Map(legalAccountantDto, existingLegalAccountant);

            _unitOfWork.Repository<LegalAccountant>().Update(existingLegalAccountant);
            await _unitOfWork.SaveChangesAsync();
        }


    }
}
