﻿using AutoMapper;
using CyrusCRM.Areas.CRM.Models;
using Domain.Contracts;
using Service.Contracts.Dtos.LeadHistoryDto;
using Service.Contracts.Managers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class LeadHistoryManager:ILeadHistoryManager
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public LeadHistoryManager(IUnitOfWork unitOfWork,IMapper mapper)
        {
            _unitOfWork = unitOfWork;
           _mapper = mapper;
        }
        public async Task AddLeadHistoryAsync(LeadHistoryDto leadHistoryDto)
        {
            if (leadHistoryDto == null)
            {
                throw new ArgumentNullException(nameof(leadHistoryDto));
            }

            var leadHistoryEntity = _mapper.Map<LeadHistory>(leadHistoryDto);

            await _unitOfWork.Repository<LeadHistory>().AddAsync(leadHistoryEntity);
            await _unitOfWork.SaveChangesAsync();
        }

 

        public async Task DeleteLeadHistoryAsync(int id)
        {
            var leadHistory = await _unitOfWork.Repository<LeadHistory>().GetByIdAsync(id);
            if (leadHistory != null)
            {
                _unitOfWork.Repository<LeadHistory>().Delete(leadHistory);
                await _unitOfWork.SaveChangesAsync();
            }
        }

   

        public async Task <IEnumerable<LeadHistoryDto>> GetAllLeadHistoryAsync()
        {
            var leadHistories = await _unitOfWork.Repository<LeadHistory>().GetAllAsync();
            return _mapper.Map<IEnumerable<LeadHistoryDto>>(leadHistories);
        }

        public Task<IEnumerable<LeadHistoryDto>> GetAllLeadHistorysAsync()
        {
            var leads = _unitOfWork.Repository<LeadHistory>().GetAllAsync();
            return (Task<IEnumerable<LeadHistoryDto>>)_mapper.Map<IEnumerable<LeadHistoryDto>>(leads);
        }

        public async Task<LeadHistoryDto> GetLeadHistoryByIdAsync(int id)
        {
            var leadHistory = await _unitOfWork.Repository<LeadHistory>().GetByIdAsync(id);
            return _mapper.Map<LeadHistoryDto>(leadHistory);
        }

 

        public async Task UpdateLeadHistoryAsync(LeadHistoryDto leadHistoryDto)
        {
            if (leadHistoryDto == null)
            {
                throw new ArgumentNullException(nameof(leadHistoryDto));
            }

            var existingLeadHistory = await _unitOfWork.Repository<LeadHistory>().GetByIdAsync(leadHistoryDto.Id);
            if (existingLeadHistory == null)
            {
                throw new ArgumentException($"LeadHistory with ID {leadHistoryDto.Id} not found.");
            }

            _mapper.Map(leadHistoryDto, existingLeadHistory);

            _unitOfWork.Repository<LeadHistory>().Update(existingLeadHistory);
            await _unitOfWork.SaveChangesAsync();
        }




    }
}
