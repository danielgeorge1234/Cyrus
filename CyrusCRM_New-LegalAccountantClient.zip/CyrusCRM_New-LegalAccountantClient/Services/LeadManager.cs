﻿using AutoMapper;
using CyrusCRM.Areas.CRM.Models;
using Domain.Contracts;
using Service.Contracts.Dtos.LeadDto;
using Service.Contracts.Managers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class LeadManager:ILeadManager
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public LeadManager(IUnitOfWork unitOfWork , IMapper mapper)
        {
            _unitOfWork = unitOfWork;
           _mapper = mapper;
        }
        public async Task AddLeadAsync(LeadDto leadDto)
        {
            if (leadDto == null)
            {
                throw new ArgumentNullException(nameof(leadDto));
            }

            var leadEntity = _mapper.Map<Lead>(leadDto);

            await _unitOfWork.Repository<Lead>().AddAsync(leadEntity);
            await _unitOfWork.SaveChangesAsync();
        }

        public async Task DeleteLeadAsync(int id)
        {
            var lead = await _unitOfWork.Repository<Lead>().GetByIdAsync(id);
            if (lead != null)
            {
                _unitOfWork.Repository<Lead>().Delete(lead);
                await _unitOfWork.SaveChangesAsync();
            }
        }

        public async Task<IEnumerable<LeadDto>> GetLeadsAsync()
        {
            var leads = await _unitOfWork.Repository<Lead>().GetAllAsync();
            return _mapper.Map<IEnumerable<LeadDto>>(leads);
        }

        public async Task<LeadDto> GetLeadByIdAsync(int id)
        {
            var lead = await _unitOfWork.Repository<Lead>().GetByIdAsync(id);
            return _mapper.Map<LeadDto>(lead);
        }

        public async Task UpdateLeadAsync(LeadDto leadDto)
        {
            if (leadDto == null)
            {
                throw new ArgumentNullException(nameof(leadDto));
            }

            var existingLead = await _unitOfWork.Repository<Lead>().GetByIdAsync(leadDto.Id);
            if (existingLead == null)
            {
                throw new ArgumentException($"Lead with ID {leadDto.Id} not found.");
            }

            _mapper.Map(leadDto, existingLead);

            _unitOfWork.Repository<Lead>().Update(existingLead);
            await _unitOfWork.SaveChangesAsync();
        }


    }
}
