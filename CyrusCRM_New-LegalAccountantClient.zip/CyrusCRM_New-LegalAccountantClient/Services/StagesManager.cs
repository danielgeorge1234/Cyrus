﻿using AutoMapper;
using CyrusCRM.Areas.CRM.Models;
using Domain.Contracts;
using Service.Contracts.Dtos.StagesDto;
using Service.Contracts.Managers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class StagesManager:IStagesManager
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public StagesManager(IUnitOfWork unitOfWork,IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public async Task AddStagesAsync(StagesDto stageDto)
        {
            if (stageDto == null)
            {
                throw new ArgumentNullException(nameof(stageDto));
            }

            var stageEntity = _mapper.Map<Stages>(stageDto);

            await _unitOfWork.Repository<Stages>().AddAsync(stageEntity);
            await _unitOfWork.SaveChangesAsync();
        }

   

        public async Task DeleteStagesAsync(int id)
        {
            var stage = await _unitOfWork.Repository<Stages>().GetByIdAsync(id);
            if (stage != null)
            {
                _unitOfWork.Repository<Stages>().Delete(stage);
                await _unitOfWork.SaveChangesAsync();
            }
        }

 

        public async Task<IEnumerable<StagesDto>> GeAllStagesDtoAsync()
        {
            var stages01 = await _unitOfWork.Repository<Stages>().GetAllAsync();
            return _mapper.Map<IEnumerable<StagesDto>>(stages01);
        }



        public async Task<StagesDto> GetStagesByIdAsync(int id)
        {
            var stage = await _unitOfWork.Repository<Stages>().GetByIdAsync(id);
            return _mapper.Map<StagesDto>(stage);
        }



        public async Task UpdateStagesAsync(StagesDto stageDto)
        {
            if (stageDto == null)
            {
                throw new ArgumentNullException(nameof(stageDto));
            }

            var existingStage = await _unitOfWork.Repository<Stages>().GetByIdAsync(stageDto.Id);
            if (existingStage == null)
            {
                throw new ArgumentException($"Stage with ID {stageDto.Id} not found.");
            }

            _mapper.Map(stageDto, existingStage);

            _unitOfWork.Repository<Stages>().Update(existingStage);
            await _unitOfWork.SaveChangesAsync();
        }

     
    }
}



    

