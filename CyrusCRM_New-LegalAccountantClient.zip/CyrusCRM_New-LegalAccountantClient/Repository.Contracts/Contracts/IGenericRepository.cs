﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Contracts.Contracts
{
    public interface IGenericRepository<T> where T : class
    {

        Task<IEnumerable<T>> GetAllAsync();
        Task<(int Total,IEnumerable<T> Entities)> GetPaginatedAsync(int PageNumber,int PageSize,Expression<Func<T, bool>>? predicate=null,params string[] includes);
        Task<IEnumerable<T>> GetsByConditionAsync(Expression<Func<T,bool>> predicate,params string[] includes);
        Task<T> GetByConditionAsync(Expression<Func<T,bool>> predicate,params string[] includes);
        Task<T> GetByIdAsync(int id,params string[] includes);
        Task AddAsync(T entity);
        void Update(T entity);
        void Delete(T entity);



    }
}
